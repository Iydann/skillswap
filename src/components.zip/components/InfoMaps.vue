<template>
  <section class="bg-gray-200 py-16">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h2 class="text-3xl font-bold text-black">Contact Info</h2>
          <p class="mt-3 text-gray-600">Feel free to reach us through the following channels.</p>
          <ul class="mt-6 space-y-3 text-gray-600">
            <li><span class="font-semibold">Email:</span> skillswap.co.id</li>
            <li><span class="font-semibold">Phone:</span> +62 895-2214-2400</li>
            <li><span class="font-semibold">Address:</span> Balikpapan, Indonesia</li>
          </ul>
        </div>
        <div>
          <div class="aspect-video rounded-xl overflow-hidden border border-white/10 bg-gray-800">
            <img 
              src="../assets/maps.png" 
              alt="Maps Location"
              class="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>