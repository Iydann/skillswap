<script setup>
import Hero from './Hero.vue';
import HowItWorks from './HowItWorks.vue';
import CTA from './CTA.vue';
import Navbar from './Navbar.vue';
import Footer from './Footer.vue';
</script>

<template>
  <Navbar />
  <Hero />
  <HowItWorks />
  <CTA />
  <Footer />
</template>