<template>
    <div class="bg-gray-200 py-16">
  <div class="mx-auto max-w-7xl px-6 lg:px-12">
    <div class="relative overflow-hidden bg-gray-800 rounded-3xl">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        <!-- Left Content -->
        <div class="px-8 py-16 lg:px-16 lg:py-20">
          <h2 class="text-3xl font-semibold text-white sm:text-4xl mb-6">About SkillSwap</h2>
          <p class="text-base text-gray-300 mb-6">
            SkillSwap is a platform that connects creative professionals and freelancers to exchange skills and collaborate on projects. Instead of monetary transactions, we facilitate skill-for-skill trades, helping you build your portfolio while getting the services you need.
          </p>
          <p class="text-base text-gray-300 mb-8">
            Whether you're a designer, developer, writer, or marketer, SkillSwap empowers you to grow your network and complete projects through meaningful collaboration.
          </p>
          <div class="flex justify-start">
            <router-link to="/contact" class="rounded-lg bg-black px-8 py-3 text-sm font-semibold text-white hover:bg-gray-900 transition">
              Contact Us
            </router-link>
          </div>
        </div>

        <!-- Right Image -->
        <div class="relative h-full min-h-[400px] lg:min-h-[500px]">
          <img 
            src="../assets/company.png" 
            alt="SkillSwap Community" 
            class="absolute inset-0 w-full h-full object-cover rounded-r-3xl"
          />
        </div>
      </div>
    </div>
  </div>
</div>

</template>